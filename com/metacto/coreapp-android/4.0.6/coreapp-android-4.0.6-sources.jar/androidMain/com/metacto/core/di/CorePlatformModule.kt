package com.metacto.core.di

import com.metacto.core.CoreEnvironment
import com.metacto.core.domain.DiQualifiers
import com.metacto.core.domain.repos.RepositoriesFactory
import com.metacto.core.domain.repos.forceUpdate.ForceUpdateRepository
import com.metacto.core.permissions.IPermissionManager
import com.metacto.core.permissions.PermissionManager
import com.metacto.core.presentation.base.CommonViewModel
import com.metacto.core.presentation.camera.CameraController
import com.metacto.core.presentation.camera.CameraEngine
import com.metacto.core.presentation.camera.models.CameraLens
import com.metacto.core.presentation.components.audioPlayer.AudioPlayerManager
import com.metacto.core.presentation.components.videoPlayer.VideoPlayerManager
import com.metacto.core.presentation.itemPicker.NativeItemPicker
import com.metacto.core.utils.calendar.CalendarManager
import com.metacto.core.utils.calendar.ICalendarManager
import com.metacto.core.utils.eventBroadcaster.EventBroadcaster
import com.metacto.core.utils.file.FileManager
import com.metacto.core.utils.file.IFileManager
import com.metacto.core.utils.imagePreloader.IPreloader
import com.metacto.core.utils.imagePreloader.Preloader
import com.metacto.core.utils.language.ILanguageManager
import com.metacto.core.utils.language.LanguageManager
import com.metacto.core.utils.launchers.IIntentLauncher
import com.metacto.core.utils.launchers.IntentLauncher
import com.metacto.core.utils.media.IMediaManager
import com.metacto.core.utils.media.MediaManager
import com.metacto.core.utils.notification.INotificationManager
import com.metacto.core.utils.notification.NotificationManager
import com.metacto.coreApp.R
import com.metacto.strapikmm.errorhandling.SerializableNetworkError
import com.metacto.strapikmm.repos.AppConfigurationRepository
import com.mmk.kmpnotifier.notification.NotifierManager
import com.mmk.kmpnotifier.notification.configuration.NotificationPlatformConfiguration
import dev.gitlive.firebase.Firebase
import dev.gitlive.firebase.remoteconfig.remoteConfig
import io.michaelrocks.libphonenumber.kotlin.MetadataLoader
import io.michaelrocks.libphonenumber.kotlin.metadata.source.AssetsMetadataLoader
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModel
import org.koin.core.definition.Definition
import org.koin.core.definition.KoinDefinition
import org.koin.core.module.Module
import org.koin.core.qualifier.Qualifier
import org.koin.dsl.module
import kotlin.reflect.KClass

actual fun <T : SerializableNetworkError> corePlatformModule(
    appStorageName: String,
    coreEnvironment: CoreEnvironment,
    shouldShowActualErrorMessages: Boolean,
    errorClass: KClass<T>
) = module {
    single {
        RepositoriesFactory<T>(
            context = androidContext(),
            environment = get(),
            appStorageName = appStorageName,
            shouldShowActualErrorMessages = shouldShowActualErrorMessages,
            errorClass = errorClass
        )
    }

    single<IPreloader> {
        Preloader(
            context = androidContext().applicationContext
        )
    }

    single {
        EventBroadcaster
    }

    single {
        Firebase.remoteConfig
    }

    single<INotificationManager> {
        NotificationManager(
            context = androidContext(),
            notifier = get()
        )
    }

    single<IPermissionManager> {
        PermissionManager(androidContext())
    }

    single<IIntentLauncher> {
        IntentLauncher(androidContext(), get())
    }

    single<ICalendarManager> {
        CalendarManager(androidContext(), get())
    }

    single<ILanguageManager> {
        LanguageManager(get())
    }

    single<MetadataLoader> {
        AssetsMetadataLoader(androidApplication().assets)
    }

    single<AppConfigurationRepository> {
        AppConfigurationRepository(
            applicationContext = androidContext(),
            appConfigurationService = get(),
            sharedPreference = get(),
            appConfigurationExpirationInMinutes = coreEnvironment.appConfigurationExpirationInMinutes
        )
    }

    single<ForceUpdateRepository> {
        ForceUpdateRepository(
            appEnvironment = get(),
            applicationContext = androidContext(),
            appConfigurationRepository = get(),
            remoteConfigs = get(),
        )
    }

    single<MutableMap<String, VideoPlayerManager>>(DiQualifiers.videoPlayerManagers) {
        mutableMapOf()
    }

    single<MutableMap<String, AudioPlayerManager>>(DiQualifiers.audioPlayerManagers) {
        mutableMapOf()
    }

    single<NotifierManager> {
        NotifierManager.apply {
            initialize(
                configuration = NotificationPlatformConfiguration.Android(
                    showPushNotification = coreEnvironment.showRemoteNotifications,
                    notificationChannelData = NotificationPlatformConfiguration.Android.NotificationChannelData(),
                    notificationIconResId = coreEnvironment.androidRemoteNotificationIcon
                        ?: R.drawable.ic_default_notifications_icon,
                )
            )
        }
    }

    single<IFileManager> {
        FileManager()
    }

    single<IMediaManager> {
        MediaManager()
    }

    factory { (defaultCamera: CameraLens?) ->
        val cameraEngine = CameraEngine(
            context = androidContext(),
            defaultCamera = defaultCamera ?: CameraLens.BACK
        )
        CameraController(
            permissionManager = get(),
            cameraEngine = cameraEngine
        )
    }

    single {
        NativeItemPicker()
    }
}

actual inline fun <reified T : CommonViewModel> Module.commonViewModel(
    qualifier: Qualifier?,
    noinline definition: Definition<T>
): KoinDefinition<T> {
    return viewModel(qualifier, definition)
}