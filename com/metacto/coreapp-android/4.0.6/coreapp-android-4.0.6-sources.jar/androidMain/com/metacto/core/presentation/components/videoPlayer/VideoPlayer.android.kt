package com.metacto.core.presentation.components.videoPlayer

import android.annotation.SuppressLint
import android.content.res.Configuration
import android.view.SurfaceView
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.metacto.core.domain.DiQualifiers
import com.metacto.core.presentation.components.dialog.dismissFullScreenDialog
import com.metacto.core.presentation.components.dialog.showFullScreenDialog
import com.metacto.core.presentation.components.visibilities.FadeVisibility
import com.metacto.core.utils.extensions.OnLifecycleEvent
import com.metacto.core.utils.extensions.getActivity
import com.metacto.core.utils.extensions.noRippleClickable
import com.metacto.core.utils.extensions.setPortraitOrientation
import com.metacto.core.utils.extensions.setUnspecifiedOrientation
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.painterResource
import org.koin.compose.koinInject
import kotlin.time.Duration
import kotlin.time.DurationUnit
import kotlin.time.toDuration

private const val CONTROLS_ANIM_DURATION = 150

@OptIn(UnstableApi::class)
@Composable
actual fun VideoPlayer(
    modifier: Modifier,
    uniqueId: String,
    videoUrl: String,
    videoArtist: String?,
    videoTitle: String?,
    videoArtworkUrl: String?,
    autoPlay: Boolean,
    scaleToCrop: Boolean,
    enablePip: Boolean,
    enableMediaMetadata: Boolean,
    enableVoice: Boolean,
    autoRepeat: Boolean,
    handleLifecyclePause: Boolean,
    controllerShowTimeoutMs: Int,
    controlsType: ControlsType,
    playIconRes: DrawableResource,
    pauseIconRes: DrawableResource,
    customControlsSize: Dp,
    customControlsElevation: Dp,
    customControlsShape: RoundedCornerShape,
    onPlayerCreated: ((VideoPlayerController) -> Unit)?,
    onDurationCaught: ((Duration) -> Unit)?,
    onVideoLoop: (() -> Unit)?,
    onVideoEnd: (() -> Unit)?,
    onVideoStarted: (() -> Unit)?,
    onVideoPaused: (() -> Unit)?,
    onVideoResumed: (() -> Unit)?
) {
    // Inject main stuff
    val playerManagers =
        koinInject<MutableMap<String, VideoPlayerManager>>(DiQualifiers.videoPlayerManagers)
    val playerManager = playerManagers.getOrPut(uniqueId) {
        VideoPlayerManager(uniqueId)
    }
    // Local state variables for UI and playback.
    val isPlaying = remember { mutableStateOf(playerManager.exoPlayer.isPlaying) }
    val icon = if (isPlaying.value) pauseIconRes else playIconRes
    val isPlayButtonVisible by remember { mutableStateOf(true) }
    val isVideoEnded = remember { mutableStateOf(false) }
    val isFullScreen = remember { mutableStateOf(false) }
    val activity = LocalContext.current.getActivity<AppCompatActivity>()
    val configuration = LocalConfiguration.current
    val isLandscape by remember(configuration.orientation) {
        derivedStateOf {
            configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        }
    }

    // Set fullscreen by default when move to landscape
    LaunchedEffect(isLandscape) {
        if (isLandscape) {
            isFullScreen.value = true
        }
    }

    // Handle fullscreen changes
    LaunchedEffect(isFullScreen.value) {
        if (isFullScreen.value) {
            activity?.setUnspecifiedOrientation()
        } else {
            activity?.setPortraitOrientation()
        }
    }

    // Show and dismiss fullscreen dialog when needed
    LaunchedEffect(isFullScreen.value) {
        if (isFullScreen.value) {
            // Show fullscreen dialog if needed
            activity?.showFullScreenDialog {
                FullScreenVideoPlayer(
                    modifier = Modifier,
                    playerManager = playerManager,
                    isPlayButtonVisible = isPlayButtonVisible,
                    icon = icon,
                    isPlaying = isPlaying,
                    isVideoEnded = isVideoEnded,
                    isFullScreen = isFullScreen,
                    controllerShowTimeoutMs = controllerShowTimeoutMs,
                    controlsType = controlsType,
                    customControlsSize = customControlsSize,
                    customControlsElevation = customControlsElevation,
                    customControlsShape = customControlsShape
                )
            }
        } else {
            // Dismiss current fullscreen dialog if exists
            activity?.dismissFullScreenDialog()
        }
    }

    // Listen for player state changes.
    LaunchedEffect(playerManager.exoPlayer) {
        playerManager.exoPlayer.addListener(object : Player.Listener {
            private var hasStarted = false

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                isPlaying.value = playWhenReady

                if (playWhenReady && playerManager.exoPlayer.playbackState == Player.STATE_READY) {
                    if (hasStarted.not()) {
                        hasStarted = true
                        onVideoStarted?.invoke()
                    } else {
                        onVideoResumed?.invoke()
                    }
                } else if (playWhenReady.not()) {
                    onVideoPaused?.invoke()
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_ENDED) {
                    isVideoEnded.value = autoRepeat.not()
                }
                if (state == Player.STATE_READY) {
                    val durationMs = playerManager.exoPlayer.duration
                    if (durationMs != C.TIME_UNSET) {
                        onDurationCaught?.invoke(durationMs.toDuration(DurationUnit.MILLISECONDS))
                    }
                }

                if (playerManager.exoPlayer.playWhenReady && !hasStarted) {
                    hasStarted = true
                    onVideoStarted?.invoke()
                }
            }
        })
    }

    // Voice configuration
    LaunchedEffect(playerManager, enableVoice) {
        playerManager.exoPlayer.volume = if (enableVoice) 1f else 0f
    }

    // Setup scaling mode
    LaunchedEffect(playerManager, scaleToCrop) {
        playerManager.setScaleToCrop(scaleToCrop)
    }

    // Auto play configuration
    LaunchedEffect(playerManager, autoPlay) {
        playerManager.setAutoPlay(autoPlay)
    }

    // Auto repeat configuration
    LaunchedEffect(playerManager, autoRepeat) {
        playerManager.setAutoRepeat(autoRepeat)
    }

    // Media metadata configuration
    LaunchedEffect(playerManager, videoUrl, videoTitle, videoArtist, videoArtworkUrl) {
        playerManager.setMedia(
            videoUrl = videoUrl,
            videoTitle = videoTitle,
            videoArtist = videoArtist,
            videoArtworkUrl = videoArtworkUrl
        )
    }
    LaunchedEffect(enableMediaMetadata) {
        playerManager.setMediaMetadataEnabled(enableMediaMetadata)
    }

    // Set up and deliver the player controller callback.
    val controller = remember(playerManager) {
        object : VideoPlayerController {
            override fun play() = playerManager.play()
            override fun pause() = playerManager.pause()
        }
    }

    LaunchedEffect(controller, onPlayerCreated) {
        onPlayerCreated?.invoke(controller)
    }

    // Video loop configuration
    LaunchedEffect(onVideoLoop) {
        playerManager.onVideoLoop = onVideoLoop
    }

    // Video end configuration
    LaunchedEffect(onVideoEnd) {
        playerManager.onVideoEnd = onVideoEnd
    }

    // Render normal video player if needed
    if (isFullScreen.value.not()) {
        NormalVideoPlayer(
            modifier = modifier,
            playerManager = playerManager,
            isPlayButtonVisible = isPlayButtonVisible,
            icon = icon,
            isPlaying = isPlaying,
            isVideoEnded = isVideoEnded,
            isFullScreen = isFullScreen,
            scaleToCrop = scaleToCrop,
            controllerShowTimeoutMs = controllerShowTimeoutMs,
            controlsType = controlsType,
            customControlsSize = customControlsSize,
            customControlsElevation = customControlsElevation,
            customControlsShape = customControlsShape
        )
    }

    // Pause the player when the composable is disposed or when the lifecycle pauses.
    DisposableEffect(Unit) {
        onDispose {
            if (handleLifecyclePause) {
                playerManager.pause()
            }
        }
    }
    OnLifecycleEvent(
        onPause = {
            if (handleLifecyclePause) {
                playerManager.pause()
            }
        }
    )
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
private fun NormalVideoPlayer(
    modifier: Modifier,
    playerManager: VideoPlayerManager,
    isPlayButtonVisible: Boolean,
    icon: DrawableResource,
    isPlaying: MutableState<Boolean>,
    isVideoEnded: MutableState<Boolean>,
    isFullScreen: MutableState<Boolean>,
    scaleToCrop: Boolean,
    controllerShowTimeoutMs: Int,
    controlsType: ControlsType,
    customControlsSize: Dp,
    customControlsElevation: Dp,
    customControlsShape: RoundedCornerShape
) {
    Box(
        modifier = modifier
    ) {
        VideoPlayerContent(
            playerManager = playerManager,
            controlsType = controlsType,
            controllerShowTimeoutMs = controllerShowTimeoutMs,
            isPlayButtonVisible = isPlayButtonVisible,
            icon = icon,
            customControlsSize = customControlsSize,
            customControlsElevation = customControlsElevation,
            customControlsShape = customControlsShape,
            resizeMode = when (scaleToCrop) {
                true -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                false -> AspectRatioFrameLayout.RESIZE_MODE_FIT
            },
            onNativeFullscreenClick = {
                isFullScreen.value = isFullScreen.value.not()
            },
            onTogglePlay = {
                if (isPlaying.value) {
                    playerManager.pause()
                } else {
                    if (isVideoEnded.value) {
                        playerManager.exoPlayer.seekTo(0)
                        isVideoEnded.value = false
                    }
                    playerManager.play()
                    isPlaying.value = true
                }
            }
        )
    }
}

@SuppressLint("UnsafeOptInUsageError")
@Composable
private fun FullScreenVideoPlayer(
    modifier: Modifier,
    playerManager: VideoPlayerManager,
    isPlayButtonVisible: Boolean,
    icon: DrawableResource,
    isPlaying: MutableState<Boolean>,
    isVideoEnded: MutableState<Boolean>,
    isFullScreen: MutableState<Boolean>,
    controllerShowTimeoutMs: Int,
    controlsType: ControlsType,
    customControlsSize: Dp,
    customControlsElevation: Dp,
    customControlsShape: RoundedCornerShape
) {
    Box(
        modifier = modifier.fillMaxSize()
    ) {
        VideoPlayerContent(
            playerManager = playerManager,
            controlsType = controlsType,
            controllerShowTimeoutMs = controllerShowTimeoutMs,
            isPlayButtonVisible = isPlayButtonVisible,
            icon = icon,
            customControlsSize = customControlsSize,
            customControlsElevation = customControlsElevation,
            customControlsShape = customControlsShape,
            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIXED_WIDTH,
            onTogglePlay = {
                if (isPlaying.value) {
                    playerManager.pause()
                } else {
                    if (isVideoEnded.value) {
                        playerManager.exoPlayer.seekTo(0)
                        isVideoEnded.value = false
                    }
                    playerManager.play()
                    isPlaying.value = true
                }
            },
            onNativeFullscreenClick = {
                isFullScreen.value = isFullScreen.value.not()
            }
        )
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun VideoPlayerContent(
    playerManager: VideoPlayerManager,
    controlsType: ControlsType,
    controllerShowTimeoutMs: Int,
    resizeMode: Int,
    isPlayButtonVisible: Boolean,
    icon: DrawableResource,
    customControlsSize: Dp,
    customControlsElevation: Dp,
    customControlsShape: RoundedCornerShape,
    onTogglePlay: () -> Unit,
    onNativeFullscreenClick: () -> Unit,
) {
    Box(modifier = Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier
                .fillMaxSize(),
            factory = { context ->
                PlayerView(context).apply {
                    useController = (controlsType == ControlsType.NativeControls)
                    this.controllerShowTimeoutMs = controllerShowTimeoutMs
                    this.resizeMode = resizeMode
                    player = playerManager.exoPlayer
                    layoutParams = FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT)

                    (videoSurfaceView as? SurfaceView)?.let {
                        playerManager.exoPlayer.setVideoSurfaceView(it)
                    }
                    if (controlsType == ControlsType.NativeControls) {
                        // Leverage native full screen button.
                        setFullscreenButtonClickListener { onNativeFullscreenClick() }
                    }
                }
            },
            update = { playerView ->
                (playerView.videoSurfaceView as? SurfaceView)?.let {
                    playerManager.exoPlayer.setVideoSurfaceView(it)
                }
            }
        )
        // For custom controls, overlay a play/pause button.
        if (controlsType == ControlsType.CustomControls) {
            FadeVisibility(
                visible = isPlayButtonVisible,
                duration = CONTROLS_ANIM_DURATION,
                modifier = Modifier.align(Alignment.Center)
            ) {
                Image(
                    painter = painterResource(icon),
                    contentDescription = null,
                    modifier = Modifier
                        .size(customControlsSize)
                        .shadow(
                            elevation = customControlsElevation,
                            shape = customControlsShape
                        )
                        .noRippleClickable { onTogglePlay() }
                )
            }
        }
    }
}