package com.metacto.core.domain

object CoreConstants {
    const val FIRST_PAGE = 1
    const val DEFAULT_PAGE_SIZE = 20
    const val MAX_PAGE_SIZE = 100
    const val SERVER_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    const val YEAR_MONTH_DAY_DATE_FORMAT = "yyyy-MM-dd"
    const val US_COUNTRY_CODE = "US"
    const val CACHED_REMOTE_CONFIGS = "CACHED_REMOTE_CONFIGS"
    const val KEY_NOTIFICATION_ID = "KEY_NOTIFICATION_ID"
    const val KEYCHAIN_PREFERENCE_VERSION = "k_version"
}