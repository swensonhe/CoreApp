package com.metacto.core.presentation.itemPicker

import com.metacto.core.presentation.base.CoreViewModel
import com.metacto.core.presentation.itemPicker.ItemPickerContract.Effect
import com.metacto.core.presentation.itemPicker.ItemPickerContract.Event
import com.metacto.core.presentation.itemPicker.ItemPickerContract.State
import com.metacto.core.presentation.itemPicker.models.PickerItem
import com.metacto.core.utils.PlatformType
import com.metacto.core.utils.extensions.orZero


class ItemPickerViewModel : CoreViewModel<State, Event, Effect>() {

    override fun setInitialState() = State()

    override fun handleEvents(event: Event): Any = when (event) {
        is Event.Init -> init(
            items = event.items,
            selectedItem = event.selectedItem,
            canSearch = event.canSearch,
            platform = event.platform,
            maxLines = event.maxItemLines,
            displayableItemsCount = event.visibleItemCount
        )

        is Event.DoneClicked -> handleDoneClick()
        is Event.ScrollFinished -> handleScrollFinish(event.currentItemIndex)
        is Event.SearchTermChanged -> handleSearchTermChange(event.value)
        Event.ClearSearchClicked -> handleClearSearchClick()
        Event.SearchClicked -> handleSearchClick()
        Event.Disposed -> handleDispose()
    }

    private fun init(
        items: List<PickerItem>,
        selectedItem: PickerItem?,
        canSearch: Boolean,
        platform: PlatformType?,
        maxLines: Int,
        displayableItemsCount: Int
    ) {
        // Validate if already initialized
        if (currentState.isInitialized) return

        // Prepare initial item index
        val initialItemIndex = items
            .indexOfFirst { it.key == selectedItem?.key }
            .takeIf { it != -1 }
            .orZero()

        // Update state
        setState {
            copy(
                items = items,
                displayedItems = items,
                initialItemIndex = initialItemIndex,
                currentItemIndex = initialItemIndex,
                canSearch = canSearch,
                platform = platform,
                maxItemLines = maxLines,
                visibleItemCount = displayableItemsCount
            )
        }

        // Update the flag
        setState { copy(isInitialized = true) }
    }

    private fun handleDoneClick() {
        // Get selected item
        val selectedItem = currentState.displayedItems.getOrNull(currentState.currentItemIndex)

        // Check it
        if (selectedItem != null) {
            navManager.goBackWithResult(
                source = ItemPickerSheet::class.simpleName,
                result = selectedItem
            )
        } else {
            navManager.goBack()
        }
    }

    private fun handleScrollFinish(currentItemIndex: Int) {
        setState {
            copy(currentItemIndex = currentItemIndex)
        }
    }

    private fun handleSearchTermChange(value: String) {
        // Stop if value didn't change
        if (value == currentState.searchTerm) return

        // Filter items
        val filteredItems = if (value.isBlank()) {
            currentState.items
        } else {
            currentState.items.filter { it.title.contains(value, ignoreCase = true) }
        }

        // Update state
        setState {
            copy(
                searchTerm = value,
                displayedItems = filteredItems
            )
        }
    }

    private fun handleClearSearchClick() {
        // Dismiss keyboard
        coreGlobalState.dismissKeyboard()

        // Update state
        setState {
            copy(
                searchTerm = "",
                displayedItems = items
            )
        }
    }

    private fun handleSearchClick() {
        coreGlobalState.dismissKeyboard()
    }

    private fun handleDispose() {
        emitSelectedItemAsResult()
    }

    override fun onDispose() {
        emitSelectedItemAsResult()
        super.onDispose()
    }

    private fun emitSelectedItemAsResult() {
        val selectedItem = currentState.displayedItems.getOrNull(currentState.currentItemIndex) ?: return
        navManager.sendResult(
            source = ItemPickerSheet::class.simpleName,
            result = selectedItem
        )
    }
}