@file:OptIn(InternalResourceApi::class)

package com.metacto.coreApp.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.LanguageQualifier
import org.jetbrains.compose.resources.RegionQualifier
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem
import org.jetbrains.compose.resources.StringResource

private const val MD: String = "composeResources/com.metacto.coreApp.resources/"

@delegate:ResourceContentHash(-332_819_938)
internal val Res.string.action_done: StringResource by lazy {
      StringResource("string:action_done", "action_done", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 10, 27),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 10, 27),
      ))
    }

@delegate:ResourceContentHash(1_696_206_829)
internal val Res.string.can_not_find_a_suitable_app_to_perform_that_action: StringResource by lazy {
      StringResource("string:can_not_find_a_suitable_app_to_perform_that_action", "can_not_find_a_suitable_app_to_perform_that_action", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 38, 178),
      ))
    }

@delegate:ResourceContentHash(-534_781_164)
internal val Res.string.can_not_find_a_suitable_app_to_preform_that_action: StringResource by lazy {
      StringResource("string:can_not_find_a_suitable_app_to_preform_that_action", "can_not_find_a_suitable_app_to_preform_that_action", setOf(
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 10, 138),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 10, 146),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 10, 162),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 10, 142),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 10, 154),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 38, 126),
      ))
    }

@delegate:ResourceContentHash(-217_977_355)
internal val Res.string.cancel: StringResource by lazy {
      StringResource("string:cancel", "cancel", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 217, 30),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 149, 26),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 157, 26),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 173, 26),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 153, 26),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 165, 26),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 165, 22),
      ))
    }

@delegate:ResourceContentHash(-78_930_296)
internal val Res.string.choose_from_library: StringResource by lazy {
      StringResource("string:choose_from_library", "choose_from_library", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 248, 63),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 176, 63),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 184, 59),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 200, 71),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 180, 55),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 192, 59),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 188, 55),
      ))
    }

@delegate:ResourceContentHash(1_651_382_587)
internal val Res.string.confirm: StringResource by lazy {
      StringResource("string:confirm", "confirm", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 312, 31),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 240, 31),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 244, 27),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 272, 27),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 236, 27),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 252, 27),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 244, 27),
      ))
    }

@delegate:ResourceContentHash(-1_867_921_887)
internal val Res.string.error: StringResource by lazy {
      StringResource("string:error", "error", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 344, 21),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 272, 21),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 272, 21),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 300, 21),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 264, 21),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 280, 21),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 272, 21),
      ))
    }

@delegate:ResourceContentHash(-690_025_272)
internal val Res.string.force_update_title: StringResource by lazy {
      StringResource("string:force_update_title", "force_update_title", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 366, 54),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 294, 46),
      ))
    }

@delegate:ResourceContentHash(-349_482_936)
internal val Res.string.maximum_allowed_date_is_s: StringResource by lazy {
      StringResource("string:maximum_allowed_date_is_s", "maximum_allowed_date_is_s", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 421, 97),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 294, 81),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 294, 81),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 322, 85),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 286, 81),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 302, 77),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 341, 73),
      ))
    }

@delegate:ResourceContentHash(-1_945_071)
internal val Res.string.maximum_allowed_time_is_s: StringResource by lazy {
      StringResource("string:maximum_allowed_time_is_s", "maximum_allowed_time_is_s", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 519, 89),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 376, 81),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 376, 81),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 408, 85),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 368, 85),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 380, 85),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 415, 73),
      ))
    }

@delegate:ResourceContentHash(509_290_565)
internal val Res.string.minimum_allowed_date_is_s: StringResource by lazy {
      StringResource("string:minimum_allowed_date_is_s", "minimum_allowed_date_is_s", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 609, 97),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 458, 81),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 458, 81),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 494, 85),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 454, 81),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 466, 77),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 489, 73),
      ))
    }

@delegate:ResourceContentHash(1_088_599_711)
internal val Res.string.minimum_allowed_time_is_s: StringResource by lazy {
      StringResource("string:minimum_allowed_time_is_s", "minimum_allowed_time_is_s", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 707, 89),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 540, 81),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 540, 81),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 580, 85),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 536, 81),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 544, 85),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 563, 73),
      ))
    }

@delegate:ResourceContentHash(470_974_962)
internal val Res.string.no_browser_installed: StringResource by lazy {
      StringResource("string:no_browser_installed", "no_browser_installed", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 797, 72),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 622, 60),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 622, 64),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 666, 64),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 618, 64),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 630, 64),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 637, 56),
      ))
    }

@delegate:ResourceContentHash(1_845_511_114)
internal val Res.string.no_email_apps_found_on_your_device: StringResource by lazy {
      StringResource("string:no_email_apps_found_on_your_device", "no_email_apps_found_on_your_device", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 870, 154),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 683, 102),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 687, 122),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 731, 126),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 683, 102),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 695, 106),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 694, 94),
      ))
    }

@delegate:ResourceContentHash(1_423_955_826)
internal val Res.string.no_internet_connection_check_connection: StringResource by lazy {
      StringResource("string:no_internet_connection_check_connection", "no_internet_connection_check_connection", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1025, 151),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 786, 139),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 810, 127),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 858, 131),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 786, 131),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 802, 123),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 789, 131),
      ))
    }

@delegate:ResourceContentHash(457_814_276)
internal val Res.string.no_phone_apps_found_on_your_device: StringResource by lazy {
      StringResource("string:no_phone_apps_found_on_your_device", "no_phone_apps_found_on_your_device", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1177, 130),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 926, 102),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 938, 126),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 990, 126),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 918, 106),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 926, 106),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 921, 94),
      ))
    }

@delegate:ResourceContentHash(590_072_476)
internal val Res.string.no_results: StringResource by lazy {
      StringResource("string:no_results", "no_results", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1416, 50),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1133, 42),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1149, 38),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1209, 38),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1133, 42),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1121, 38),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1104, 34),
      ))
    }

@delegate:ResourceContentHash(-1_099_318_332)
internal val Res.string.no_results_subtitle: StringResource by lazy {
      StringResource("string:no_results_subtitle", "no_results_subtitle", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1308, 107),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1029, 103),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1065, 83),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1117, 91),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1025, 107),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1033, 87),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1016, 87),
      ))
    }

@delegate:ResourceContentHash(1_581_024_460)
internal val Res.string.ok: StringResource by lazy {
      StringResource("string:ok", "ok", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1467, 26),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1176, 14),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1188, 14),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1248, 14),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1176, 14),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1160, 14),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1139, 14),
      ))
    }

@delegate:ResourceContentHash(-1_693_149_684)
internal val Res.string.`override`: StringResource by lazy {
      StringResource("string:override", "override", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1730, 32),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1314, 28),
      ))
    }

@delegate:ResourceContentHash(218_288_264)
internal val Res.string.override_current_user: StringResource by lazy {
      StringResource("string:override_current_user", "override_current_user", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1644, 85),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1256, 57),
      ))
    }

@delegate:ResourceContentHash(1_848_453_908)
internal val Res.string.override_current_user_message: StringResource by lazy {
      StringResource("string:override_current_user_message", "override_current_user_message", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1494, 149),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1154, 101),
      ))
    }

@delegate:ResourceContentHash(1_622_830_689)
internal val Res.string.remove_current_photo: StringResource by lazy {
      StringResource("string:remove_current_photo", "remove_current_photo", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1763, 80),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1191, 60),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1203, 56),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1263, 64),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1191, 56),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1175, 52),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1343, 56),
      ))
    }

@delegate:ResourceContentHash(-1_830_193_283)
internal val Res.string.reset_current_user: StringResource by lazy {
      StringResource("string:reset_current_user", "reset_current_user", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1844, 94),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1400, 50),
      ))
    }

@delegate:ResourceContentHash(1_549_734_273)
internal val Res.string.search_here: StringResource by lazy {
      StringResource("string:search_here", "search_here", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1939, 43),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1252, 39),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1260, 39),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1328, 43),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1248, 35),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1228, 43),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1451, 39),
      ))
    }

@delegate:ResourceContentHash(-1_583_439_722)
internal val Res.string.server_taking_too_long: StringResource by lazy {
      StringResource("string:server_taking_too_long", "server_taking_too_long", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 1983, 202),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1292, 170),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1300, 166),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1372, 146),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1284, 146),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1272, 162),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1491, 134),
      ))
    }

@delegate:ResourceContentHash(138_647_338)
internal val Res.string.session_expired: StringResource by lazy {
      StringResource("string:session_expired", "session_expired", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2186, 55),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1463, 47),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1467, 47),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1519, 47),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1431, 47),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1435, 47),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1626, 43),
      ))
    }

@delegate:ResourceContentHash(177_787_040)
internal val Res.string.skip_update_button: StringResource by lazy {
      StringResource("string:skip_update_button", "skip_update_button", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2242, 58),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1670, 42),
      ))
    }

@delegate:ResourceContentHash(-1_750_537_084)
internal val Res.string.something_went_wrong_try_again: StringResource by lazy {
      StringResource("string:something_went_wrong_try_again", "something_went_wrong_try_again", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2301, 118),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1511, 126),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1515, 114),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1567, 122),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1479, 114),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1483, 114),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1713, 98),
      ))
    }

@delegate:ResourceContentHash(-206_410_140)
internal val Res.string.sorry_there_was_problem_connecting: StringResource by lazy {
      StringResource("string:sorry_there_was_problem_connecting", "sorry_there_was_problem_connecting", setOf(
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1812, 150),
      ))
    }

@delegate:ResourceContentHash(-15_017_483)
internal val Res.string.take_photo: StringResource by lazy {
      StringResource("string:take_photo", "take_photo", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2420, 46),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1638, 34),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1630, 34),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1690, 42),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1594, 34),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1598, 34),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1963, 34),
      ))
    }

@delegate:ResourceContentHash(-30_411_067)
internal val Res.string.update_button: StringResource by lazy {
      StringResource("string:update_button", "update_button", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2467, 49),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 1998, 37),
      ))
    }

@delegate:ResourceContentHash(342_049_538)
internal val Res.string.your_session_expired_login_again: StringResource by lazy {
      StringResource("string:your_session_expired_login_again", "your_session_expired_login_again", setOf(
        ResourceItem(setOf(LanguageQualifier("ar"), ), "${MD}values-ar/strings.commonMain.cvr", 2517, 140),
        ResourceItem(setOf(LanguageQualifier("de"), ), "${MD}values-de/strings.commonMain.cvr", 1673, 104),
        ResourceItem(setOf(LanguageQualifier("es"), ), "${MD}values-es/strings.commonMain.cvr", 1665, 120),
        ResourceItem(setOf(LanguageQualifier("fr"), ), "${MD}values-fr/strings.commonMain.cvr", 1733, 108),
        ResourceItem(setOf(LanguageQualifier("it"), ), "${MD}values-it/strings.commonMain.cvr", 1629, 116),
        ResourceItem(setOf(LanguageQualifier("pt"), RegionQualifier("BR"), ), "${MD}values-pt-rBR/strings.commonMain.cvr", 1633, 112),
        ResourceItem(setOf(), "${MD}values/strings.commonMain.cvr", 2036, 100),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainString0Resources(map: MutableMap<String, StringResource>) {
  map.put("action_done", Res.string.action_done)
  map.put("can_not_find_a_suitable_app_to_perform_that_action", Res.string.can_not_find_a_suitable_app_to_perform_that_action)
  map.put("can_not_find_a_suitable_app_to_preform_that_action", Res.string.can_not_find_a_suitable_app_to_preform_that_action)
  map.put("cancel", Res.string.cancel)
  map.put("choose_from_library", Res.string.choose_from_library)
  map.put("confirm", Res.string.confirm)
  map.put("error", Res.string.error)
  map.put("force_update_title", Res.string.force_update_title)
  map.put("maximum_allowed_date_is_s", Res.string.maximum_allowed_date_is_s)
  map.put("maximum_allowed_time_is_s", Res.string.maximum_allowed_time_is_s)
  map.put("minimum_allowed_date_is_s", Res.string.minimum_allowed_date_is_s)
  map.put("minimum_allowed_time_is_s", Res.string.minimum_allowed_time_is_s)
  map.put("no_browser_installed", Res.string.no_browser_installed)
  map.put("no_email_apps_found_on_your_device", Res.string.no_email_apps_found_on_your_device)
  map.put("no_internet_connection_check_connection", Res.string.no_internet_connection_check_connection)
  map.put("no_phone_apps_found_on_your_device", Res.string.no_phone_apps_found_on_your_device)
  map.put("no_results", Res.string.no_results)
  map.put("no_results_subtitle", Res.string.no_results_subtitle)
  map.put("ok", Res.string.ok)
  map.put("override", Res.string.`override`)
  map.put("override_current_user", Res.string.override_current_user)
  map.put("override_current_user_message", Res.string.override_current_user_message)
  map.put("remove_current_photo", Res.string.remove_current_photo)
  map.put("reset_current_user", Res.string.reset_current_user)
  map.put("search_here", Res.string.search_here)
  map.put("server_taking_too_long", Res.string.server_taking_too_long)
  map.put("session_expired", Res.string.session_expired)
  map.put("skip_update_button", Res.string.skip_update_button)
  map.put("something_went_wrong_try_again", Res.string.something_went_wrong_try_again)
  map.put("sorry_there_was_problem_connecting", Res.string.sorry_there_was_problem_connecting)
  map.put("take_photo", Res.string.take_photo)
  map.put("update_button", Res.string.update_button)
  map.put("your_session_expired_login_again", Res.string.your_session_expired_login_again)
}
