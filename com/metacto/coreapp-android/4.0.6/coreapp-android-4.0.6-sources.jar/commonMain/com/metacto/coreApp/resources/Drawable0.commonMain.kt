@file:OptIn(InternalResourceApi::class)

package com.metacto.coreApp.resources

import kotlin.OptIn
import kotlin.String
import kotlin.collections.MutableMap
import org.jetbrains.compose.resources.DrawableResource
import org.jetbrains.compose.resources.InternalResourceApi
import org.jetbrains.compose.resources.ResourceContentHash
import org.jetbrains.compose.resources.ResourceItem

private const val MD: String = "composeResources/com.metacto.coreApp.resources/"

@delegate:ResourceContentHash(-2_086_211_369)
internal val Res.drawable.ic_audio_pause: DrawableResource by lazy {
      DrawableResource("drawable:ic_audio_pause", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_audio_pause.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_262_516_969)
internal val Res.drawable.ic_audio_play: DrawableResource by lazy {
      DrawableResource("drawable:ic_audio_play", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_audio_play.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-40_231_701)
internal val Res.drawable.ic_camera: DrawableResource by lazy {
      DrawableResource("drawable:ic_camera", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_camera.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_050_869_699)
internal val Res.drawable.ic_delete: DrawableResource by lazy {
      DrawableResource("drawable:ic_delete", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_delete.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-1_657_759_586)
internal val Res.drawable.ic_pause: DrawableResource by lazy {
      DrawableResource("drawable:ic_pause", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_pause.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(1_859_471_280)
internal val Res.drawable.ic_photo_library: DrawableResource by lazy {
      DrawableResource("drawable:ic_photo_library", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_photo_library.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(-628_166_075)
internal val Res.drawable.ic_play: DrawableResource by lazy {
      DrawableResource("drawable:ic_play", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_play.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(344_292_932)
internal val Res.drawable.ic_upgrade: DrawableResource by lazy {
      DrawableResource("drawable:ic_upgrade", setOf(
        ResourceItem(setOf(), "${MD}drawable/ic_upgrade.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(761_080_313)
internal val Res.drawable.img_gray_placeholder: DrawableResource by lazy {
      DrawableResource("drawable:img_gray_placeholder", setOf(
        ResourceItem(setOf(), "${MD}drawable/img_gray_placeholder.xml", -1, -1),
      ))
    }

@delegate:ResourceContentHash(53_012_677)
internal val Res.drawable.img_white_placeholder: DrawableResource by lazy {
      DrawableResource("drawable:img_white_placeholder", setOf(
        ResourceItem(setOf(), "${MD}drawable/img_white_placeholder.xml", -1, -1),
      ))
    }

@InternalResourceApi
internal fun _collectCommonMainDrawable0Resources(map: MutableMap<String, DrawableResource>) {
  map.put("ic_audio_pause", Res.drawable.ic_audio_pause)
  map.put("ic_audio_play", Res.drawable.ic_audio_play)
  map.put("ic_camera", Res.drawable.ic_camera)
  map.put("ic_delete", Res.drawable.ic_delete)
  map.put("ic_pause", Res.drawable.ic_pause)
  map.put("ic_photo_library", Res.drawable.ic_photo_library)
  map.put("ic_play", Res.drawable.ic_play)
  map.put("ic_upgrade", Res.drawable.ic_upgrade)
  map.put("img_gray_placeholder", Res.drawable.img_gray_placeholder)
  map.put("img_white_placeholder", Res.drawable.img_white_placeholder)
}
