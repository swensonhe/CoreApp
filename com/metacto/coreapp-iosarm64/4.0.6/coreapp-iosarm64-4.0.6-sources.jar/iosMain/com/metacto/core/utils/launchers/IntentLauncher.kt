package com.metacto.core.utils.launchers

import com.metacto.core.utils.date.toNSDateComponent
import com.metacto.core.utils.delegates.EventEditDelegate
import com.metacto.core.utils.extensions.openAppSettings
import com.metacto.core.utils.extensions.runOnMainThread
import kotlinx.cinterop.ExperimentalForeignApi
import kotlinx.cinterop.useContents
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.IO
import kotlinx.coroutines.withContext
import kotlinx.datetime.LocalDateTime
import platform.CoreGraphics.CGRectMake
import platform.EventKit.EKEvent
import platform.EventKit.EKEventStore
import platform.EventKitUI.EKEventEditViewController
import platform.Foundation.NSData
import platform.Foundation.NSURL
import platform.Foundation.dataWithContentsOfURL
import platform.UIKit.UIActivityViewController
import platform.UIKit.UIApplication
import platform.UIKit.UIImage
import platform.UIKit.UIPopoverArrowDirectionAny
import platform.UIKit.popoverPresentationController

class IntentLauncher : IIntentLauncher {

    override fun launchEmail(email: String, subject: String?, body: String?) = runOnMainThread {
        val url = "mailto:$email?subject=${subject.orEmpty()}&body=${body.orEmpty()}"
        openUrl(url)
    }

    override fun launchAppInStore(appId: String) = runOnMainThread {
        // Open the url
        val url = "itms-apps://itunes.apple.com/app/$appId"
        val canOpen = openUrl(url)

        // Open browser if couldn't be opened
        if (canOpen.not()) {
            launchBrowser("https://apps.apple.com/app/$appId")
        }
    }

    @OptIn(ExperimentalForeignApi::class)
    override fun shareText(text: String) = runOnMainThread {
        // Get and validate the root view controller
        val rootViewController = UIApplication.sharedApplication
            .keyWindow
            ?.rootViewController
            ?: return@runOnMainThread

        // Create the activity controller
        val activityController = UIActivityViewController(
            activityItems = listOf(text),
            applicationActivities = null
        )

        // Configure for iPad
        activityController.popoverPresentationController?.let { popover ->
            popover.sourceView = rootViewController.view
            popover.sourceRect = CGRectMake(
                x = rootViewController.view.bounds.useContents { size.width } / 2.0,
                y = rootViewController.view.bounds.useContents { size.height } / 2.0,
                width = 0.0,
                height = 0.0
            )
            popover.permittedArrowDirections = UIPopoverArrowDirectionAny
        }

        rootViewController.presentViewController(
            viewControllerToPresent = activityController,
            animated = true,
            completion = null
        )
    }

    override fun launchPhone(phone: String) = runOnMainThread {
        val url = "tel://$phone"
        openUrl(url)
    }

    override fun launchBrowser(url: String) = runOnMainThread {
        openUrl(url)
    }

    override fun launchAppSettings() {
        openAppSettings()
    }

    override fun launchMap(latitude: Double, longitude: Double, name: String?) {
        val geoUrl = "geo:0,0?q=${latitude},${longitude}(${name})"
        val encodedUrl = geoUrl.replace(" ", "%20") // Ensure proper encoding
        val nsUrl = NSURL(string = encodedUrl)

        if (UIApplication.sharedApplication.canOpenURL(nsUrl)) {
            openUrl(geoUrl)
        } else {
            val namePart = name?.let { "(${name})" } ?: ""
            val mapUrl = "http://maps.google.com/maps?q=loc:${latitude},${longitude}$namePart"
            openUrl(mapUrl)
        }
    }

    override fun checkAppInstalled(appId: String): Boolean {
        val url = NSURL(string = "$appId://app")
        return UIApplication.sharedApplication.canOpenURL(url)
    }

    override fun openDeepLink(link: String, onError: (() -> Unit)?): Boolean {
        // Create the url
        val nsUrl = NSURL.URLWithString(link) ?: return false

        // Validate can open url
        if (UIApplication.sharedApplication.canOpenURL(nsUrl).not()) return false

        // Then open it
        runOnMainThread {
            UIApplication.sharedApplication.openURL(nsUrl, emptyMap<Any?, Any?>()) { success ->
                if (success.not()) {
                    onError?.invoke()
                }
            }
        }
        return true
    }

    override fun canHandleScheme(scheme: String, host: String?): Boolean {
        val urlString = buildString {
            append("$scheme://")
            host?.let { append(it) }
        }

        val nsUrl = NSURL.URLWithString(urlString) ?: return false

        return UIApplication.sharedApplication.canOpenURL(nsUrl)
    }

    override suspend fun shareImage(imageUrl: String, text: String?) = withContext(Dispatchers.IO) {
        // Create and validate the UIImage
        val nsUrl = requireNotNull(NSURL.URLWithString(imageUrl)) {
            "Failed to download the image"
        }
        val data = requireNotNull(NSData.dataWithContentsOfURL(nsUrl)) {
            "Failed to download the image"
        }
        val image = UIImage.imageWithData(data)

        // Get and validate the root view controller
        val rootViewController = UIApplication.sharedApplication
            .keyWindow
            ?.rootViewController
            ?: return@withContext

        // Create the activity controller
        val activityController = UIActivityViewController(
            activityItems = listOfNotNull(image, text),
            applicationActivities = null
        )

        // Then present it
        withContext(Dispatchers.Main) {
            rootViewController.presentViewController(
                viewControllerToPresent = activityController,
                animated = true,
                completion = null
            )
        }
    }

    override fun addEventToCalendar(
        eventTitle: String,
        eventDescription: String,
        eventStartTime: LocalDateTime,
        eventEndTime: LocalDateTime
    ) {
        val eventStore = EKEventStore()
                val event = EKEvent.eventWithEventStore(eventStore).apply {
                    this.title = eventTitle
                    this.notes = eventDescription
                    this.startDate = eventStartTime.toNSDateComponent().date
                    this.endDate = eventEndTime.toNSDateComponent().date
                    this.calendar = eventStore.defaultCalendarForNewEvents
                }

                runOnMainThread {
                    // Get and validate the root view controller
                    val rootViewController = UIApplication.sharedApplication
                        .keyWindow
                        ?.rootViewController
                        ?: return@runOnMainThread

                    val eventController = EKEventEditViewController().apply {
                        this.event = event
                        this.eventStore = eventStore
                        this.editViewDelegate = EventEditDelegate()
                    }

                    rootViewController.presentViewController(
                        eventController,
                        animated = true,
                        completion = null
                    )
                }
        }

    private fun openUrl(url: String): Boolean {
        // Create the url
        val nsUrl = NSURL.URLWithString(url) ?: return false

        // Validate can open url
        if (UIApplication.sharedApplication.canOpenURL(nsUrl).not()) return false

        // Then open it
        runOnMainThread {
            UIApplication.sharedApplication.openURL(nsUrl, emptyMap<Any?, Any?>(), null)
        }
        return true
    }
}
